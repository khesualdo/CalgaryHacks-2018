
<?php
	$DB_SERVER = '108.167.140.23';
	$DB_USERNAME = 'nicolas_CeroBuks';
	$DB_PASSWORD = '5LO$3c_73=]B';
	$DB_DATABASE = 'nicolas_CeroBuks';
	$db = mysqli_connect($DB_SERVER, $DB_USERNAME, $DB_PASSWORD, $DB_DATABASE) or die('Error connecting to MySQL server.');
?>

<html>
<head>
<script src="d3.min.js" charset="utf-8"></script>
</head>
<body>
<h1>PHP connect to MySQL</h1>
<?php
	$query = "SELECT * from USER";
	mysqli_query($db, $query) or die('Error querying database.');
	$result = mysqli_query($db, $query);
	
	while ($row = mysqli_fetch_array($result)) {
		echo "Hash: " . hash('sha256', $row["password"]);
	}
	mysqli_close($db);
	$str = substr(md5(mt_rand() . microtime()), mt_rand(0,35), 5);
	echo $str;
?>
</body>
</html>