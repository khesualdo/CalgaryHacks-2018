<?php
$username=$_POST['username'];
$password=$_POST['password'];
$DB_SERVER = '108.167.140.23';
$DB_USERNAME = 'nicolas_CeroBuks';
$DB_PASSWORD = '5LO$3c_73=]B';
$DB_DATABASE = 'nicolas_CeroBuks';
$con = mysqli_connect($DB_SERVER, $DB_USERNAME, $DB_PASSWORD, $DB_DATABASE) or die('Error connecting to MySQL server.');
$error ='';
if (isset($_POST['submit'])) {
	$sql="select * from USER where username='$username'";
	$result = mysqli_query($con, $sql);
	$row = mysqli_fetch_array($result);
	$rows = mysqli_num_rows($result);
	if ($rows == 1){
		$salt = $row['salt'];
		$hashpassword = hash('sha256', $salt.$password);
		if ($hashpassword == $row['password']){
         	$_SESSION['login_user'] = $username;
			header( "Location: ./dashboard.php" );	
		}
		else{
			//header( "Location: ./index.html" ); die;
			$error = 'Wrong username or password';
		}
	}
	else{
		//header( "Location: ./index.html" ); die;
		$error = 'Wrong username or password';
	}
}
?>
