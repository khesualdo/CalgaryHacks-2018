<?php
$myfirstname=$_POST['myfirstname'];
$mylastname=$_POST['mylastname'];
$myusername=$_POST['myusername'];
$mypassword=$_POST['mypassword'];
$mypasswordconfirm=$_POST['mypasswordconfirm'];
$salt='';
$hashpassword='';
$DB_SERVER = '108.167.140.23';
$DB_USERNAME = 'nicolas_CeroBuks';
$DB_PASSWORD = '5LO$3c_73=]B';
$DB_DATABASE = 'nicolas_CeroBuks';
$con = mysqli_connect($DB_SERVER, $DB_USERNAME, $DB_PASSWORD, $DB_DATABASE) or die('Error connecting to MySQL server.');
$error='';
if (isset($_POST['submit'])) {
	if ($mypassword!=$mypasswordconfirm){
		$error = "Password does not match.";
	}
	else{
	//$myusername=mysql_real_escape_string($myusername);
	//$mypassword=mysql_real_escape_string($myusername);
	$sql="SELECT * FROM USER WHERE username='$myusername'";
	$result = mysqli_query($con, $sql);
	$rows = mysqli_num_rows($result);
	if ($rows != 0){
		$error = "Username already taken.";
	}
	else{
		$salt = substr(md5(mt_rand() . microtime()), mt_rand(0,35), 5);
		$hashpassword = hash('sha256', $salt.$mypassword);
		$sql="INSERT INTO USER (username, password, salt, firstname, lastname) VALUES ('$myusername', '$hashpassword', '$salt', '$myfirstname', '$mylastname')";
		if ($con->query($sql) === TRUE){
			header( "Location: ./index.php" );
		}
		else {
			$error = "SQL error..";
		}
	}	

	}
}
?>